
Important piece of information:

If you do not own an Arduino, you can still test the application using the .apk file that ends with -DEBUG.
You may not be able to send data to an Arduino, as expected, but all the UI will be enabled by default.
This means that such application may only be a mock-up of the real application, with close to none functionality, used only for debugging purposes.